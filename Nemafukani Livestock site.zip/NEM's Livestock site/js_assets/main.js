/**
 * ===================================
 * Nemafukani Livestock Website
 * Main JavaScript File
 * Author: Nemafukani Livestock
 * Version: 1.0.0
 * ===================================
 */

'use strict';

// ===================================
// UTILITY FUNCTIONS
// ===================================

/**
 * Debounce function to limit function execution rate
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} Debounced function
 */
const debounce = (func, wait = 300) => {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
};

/**
 * Check if element is in viewport
 * @param {HTMLElement} element - Element to check
 * @returns {boolean} True if element is in viewport
 */
const isInViewport = (element) => {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
};

/**
 * Smooth scroll to element
 * @param {HTMLElement} element - Target element
 * @param {number} offset - Offset from top in pixels
 */
const smoothScrollTo = (element, offset = 80) => {
    const targetPosition = element.getBoundingClientRect().top + window.pageYOffset - offset;
    window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
    });
};

// ===================================
// MOBILE NAVIGATION TOGGLE
// ===================================

const initMobileNav = () => {
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav__link');

    if (!navToggle || !navMenu) return;

    // Toggle mobile menu
    navToggle.addEventListener('click', () => {
        navToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
        document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
    });

    // Close menu when clicking on a nav link
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
        if (!navMenu.contains(e.target) && !navToggle.contains(e.target)) {
            navToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
};

// ===================================
// STICKY HEADER ON SCROLL
// ===================================

const initStickyHeader = () => {
    const header = document.getElementById('header');
    if (!header) return;

    let lastScrollTop = 0;

    window.addEventListener('scroll', debounce(() => {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > 100) {
            header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.1)';
        } else {
            header.style.boxShadow = '0 2px 15px rgba(0, 0, 0, 0.1)';
        }

        lastScrollTop = scrollTop;
    }, 100));
};

// ===================================
// SCROLL TO TOP BUTTON
// ===================================

const initScrollToTop = () => {
    const scrollToTopBtn = document.getElementById('scrollToTop');
    if (!scrollToTopBtn) return;

    // Show/hide button based on scroll position
    window.addEventListener('scroll', debounce(() => {
        if (window.pageYOffset > 300) {
            scrollToTopBtn.classList.add('visible');
        } else {
            scrollToTopBtn.classList.remove('visible');
        }
    }, 100));

    // Scroll to top when clicked
    scrollToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
};

// ===================================
// SMOOTH SCROLL FOR ANCHOR LINKS
// ===================================

const initSmoothScroll = () => {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            
            // Ignore empty or just # links
            if (href === '#' || href === '') return;
            
            const targetElement = document.querySelector(href);
            
            if (targetElement) {
                e.preventDefault();
                smoothScrollTo(targetElement);
            }
        });
    });
};

// ===================================
// FADE-IN ANIMATIONS ON SCROLL
// ===================================

const initScrollAnimations = () => {
    const fadeElements = document.querySelectorAll('.fade-in');
    if (fadeElements.length === 0) return;

    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    fadeElements.forEach(element => {
        observer.observe(element);
    });
};

// ===================================
// FAQ ACCORDION FUNCTIONALITY
// ===================================

const initFAQAccordion = () => {
    const faqItems = document.querySelectorAll('.faq-item__question');
    if (faqItems.length === 0) return;

    faqItems.forEach(question => {
        question.addEventListener('click', () => {
            const isExpanded = question.getAttribute('aria-expanded') === 'true';
            const answer = question.nextElementSibling;

            // Close all other FAQ items
            document.querySelectorAll('.faq-item__question').forEach(q => {
                if (q !== question) {
                    q.setAttribute('aria-expanded', 'false');
                    q.nextElementSibling.style.maxHeight = null;
                }
            });

            // Toggle current FAQ item
            if (isExpanded) {
                question.setAttribute('aria-expanded', 'false');
                answer.style.maxHeight = null;
            } else {
                question.setAttribute('aria-expanded', 'true');
                answer.style.maxHeight = answer.scrollHeight + 'px';
            }
        });
    });
};

// ===================================
// FAQ SEARCH FUNCTIONALITY
// ===================================

const initFAQSearch = () => {
    const searchInput = document.getElementById('faqSearch');
    const clearButton = document.getElementById('clearSearch');
    const searchResults = document.getElementById('searchResults');
    const noResults = document.getElementById('noResults');
    const faqItems = document.querySelectorAll('.faq-item');

    if (!searchInput || faqItems.length === 0) return;

    const performSearch = debounce(() => {
        const searchTerm = searchInput.value.toLowerCase().trim();
        let visibleCount = 0;

        faqItems.forEach(item => {
            const question = item.querySelector('.faq-item__text').textContent.toLowerCase();
            const answer = item.querySelector('.faq-item__content').textContent.toLowerCase();

            if (searchTerm === '' || question.includes(searchTerm) || answer.includes(searchTerm)) {
                item.classList.remove('hidden');
                visibleCount++;
            } else {
                item.classList.add('hidden');
            }
        });

        // Show/hide clear button
        if (clearButton) {
            clearButton.style.display = searchTerm ? 'flex' : 'none';
        }

        // Update results text
        if (searchResults) {
            if (searchTerm) {
                searchResults.textContent = `Found ${visibleCount} result${visibleCount !== 1 ? 's' : ''}`;
            } else {
                searchResults.textContent = '';
            }
        }

        // Show/hide no results message
        if (noResults) {
            noResults.style.display = visibleCount === 0 && searchTerm ? 'block' : 'none';
        }
    }, 300);

    searchInput.addEventListener('input', performSearch);

    // Clear search
    if (clearButton) {
        clearButton.addEventListener('click', () => {
            searchInput.value = '';
            performSearch();
            searchInput.focus();
        });
    }
};

// ===================================
// FAQ CATEGORY FILTER
// ===================================

const initFAQCategoryFilter = () => {
    const categoryButtons = document.querySelectorAll('.faq-category-btn');
    const faqItems = document.querySelectorAll('.faq-item');

    if (categoryButtons.length === 0 || faqItems.length === 0) return;

    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            const category = button.getAttribute('data-category');

            // Update active button
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            // Filter FAQ items
            faqItems.forEach(item => {
                const itemCategory = item.getAttribute('data-category');

                if (category === 'all' || itemCategory === category) {
                    item.classList.remove('hidden');
                } else {
                    item.classList.add('hidden');
                }

                // Close all expanded items when filtering
                const question = item.querySelector('.faq-item__question');
                const answer = item.querySelector('.faq-item__answer');
                if (question && answer) {
                    question.setAttribute('aria-expanded', 'false');
                    answer.style.maxHeight = null;
                }
            });
        });
    });
};

// ===================================
// CONTACT FORM VALIDATION
// ===================================

const initContactForm = () => {
    const form = document.getElementById('contactForm');
    if (!form) return;

    // Validation rules
    const validationRules = {
        firstName: {
            required: true,
            minLength: 2,
            pattern: /^[a-zA-Z\s]+$/,
            errorMessage: 'Please enter a valid first name (letters only, minimum 2 characters)'
        },
        lastName: {
            required: true,
            minLength: 2,
            pattern: /^[a-zA-Z\s]+$/,
            errorMessage: 'Please enter a valid last name (letters only, minimum 2 characters)'
        },
        email: {
            required: true,
            pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
            errorMessage: 'Please enter a valid email address'
        },
        phone: {
            required: true,
            pattern: /^[\d\s\+\-\(\)]+$/,
            minLength: 10,
            errorMessage: 'Please enter a valid phone number (minimum 10 digits)'
        },
        subject: {
            required: true,
            errorMessage: 'Please select a subject'
        },
        message: {
            required: true,
            minLength: 10,
            errorMessage: 'Please enter a message (minimum 10 characters)'
        }
    };

    /**
     * Validate single form field
     * @param {HTMLElement} field - Input field to validate
     * @returns {boolean} True if valid
     */
    const validateField = (field) => {
        const fieldName = field.name;
        const fieldValue = field.value.trim();
        const rules = validationRules[fieldName];
        const errorElement = field.parentElement.querySelector('.form-error');

        if (!rules) return true;

        // Check required
        if (rules.required && !fieldValue) {
            showError(field, errorElement, rules.errorMessage);
            return false;
        }

        // Check min length
        if (rules.minLength && fieldValue.length < rules.minLength) {
            showError(field, errorElement, rules.errorMessage);
            return false;
        }

        // Check pattern
        if (rules.pattern && !rules.pattern.test(fieldValue)) {
            showError(field, errorElement, rules.errorMessage);
            return false;
        }

        // Field is valid
        clearError(field, errorElement);
        return true;
    };

    /**
     * Show field error
     * @param {HTMLElement} field - Input field
     * @param {HTMLElement} errorElement - Error message element
     * @param {string} message - Error message
     */
    const showError = (field, errorElement, message) => {
        field.classList.add('error');
        if (errorElement) {
            errorElement.textContent = message;
        }
    };

    /**
     * Clear field error
     * @param {HTMLElement} field - Input field
     * @param {HTMLElement} errorElement - Error message element
     */
    const clearError = (field, errorElement) => {
        field.classList.remove('error');
        if (errorElement) {
            errorElement.textContent = '';
        }
    };

    // Add real-time validation to all form fields
    const formFields = form.querySelectorAll('.form-input');
    formFields.forEach(field => {
        field.addEventListener('blur', () => validateField(field));
        field.addEventListener('input', debounce(() => {
            if (field.classList.contains('error')) {
                validateField(field);
            }
        }, 500));
    });

    // Handle form submission
    form.addEventListener('submit', (e) => {
        e.preventDefault();

        // Validate all fields
        let isValid = true;
        formFields.forEach(field => {
            if (!validateField(field)) {
                isValid = false;
            }
        });

        if (!isValid) {
            // Scroll to first error
            const firstError = form.querySelector('.error');
            if (firstError) {
                smoothScrollTo(firstError);
            }
            return;
        }

        // Show loading state
        const submitButton = form.querySelector('button[type="submit"]');
        const btnText = submitButton.querySelector('.btn-text');
        const btnLoader = submitButton.querySelector('.btn-loader');

        submitButton.disabled = true;
        btnText.style.display = 'none';
        btnLoader.style.display = 'inline-flex';

        // Simulate form submission (replace with actual API call)
        setTimeout(() => {
            // Hide loading state
            submitButton.disabled = false;
            btnText.style.display = 'inline';
            btnLoader.style.display = 'none';

            // Show success message
            const successMessage = document.getElementById('formSuccess');
            if (successMessage) {
                successMessage.style.display = 'flex';
                form.reset();

                // Hide success message after 5 seconds
                setTimeout(() => {
                    successMessage.style.display = 'none';
                }, 5000);

                // Scroll to success message
                smoothScrollTo(successMessage);
            }

            // Log form data (for testing)
            const formData = new FormData(form);
            console.log('Form submitted with data:');
            for (let [key, value] of formData.entries()) {
                console.log(`${key}: ${value}`);
            }
        }, 2000);
    });
};

// ===================================
// LIGHTBOX GALLERY
// ===================================

/**
 * Open lightbox with image
 * @param {HTMLElement} imageElement - Clicked image element
 */
window.openLightbox = (imageElement) => {
    const lightbox = document.getElementById('lightbox');
    const lightboxImage = document.getElementById('lightboxImage');
    
    if (!lightbox || !lightboxImage) return;
    
    const imgSrc = imageElement.querySelector('img').src;
    const imgAlt = imageElement.querySelector('img').alt;
    
    lightboxImage.src = imgSrc;
    lightboxImage.alt = imgAlt;
    lightbox.classList.add('active');
    document.body.style.overflow = 'hidden';
};

/**
 * Close lightbox
 */
window.closeLightbox = () => {
    const lightbox = document.getElementById('lightbox');
    if (!lightbox) return;
    
    lightbox.classList.remove('active');
    document.body.style.overflow = '';
};

// Initialize lightbox
const initLightbox = () => {
    const lightbox = document.getElementById('lightbox');
    if (!lightbox) return;

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && lightbox.classList.contains('active')) {
            closeLightbox();
        }
    });

    // Prevent closing when clicking on image
    const lightboxImage = document.getElementById('lightboxImage');
    if (lightboxImage) {
        lightboxImage.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    }
};

// ===================================
// GALLERY FILTER FUNCTIONALITY
// ===================================

const initGalleryFilters = () => {
    const filterButtons = document.querySelectorAll('.gallery-filter-btn');
    const galleryItems = document.querySelectorAll('.gallery-item');
    const totalImagesEl = document.getElementById('totalImages');
    const visibleImagesEl = document.getElementById('visibleImages');

    if (filterButtons.length === 0 || galleryItems.length === 0) return;

    // Set initial total count
    if (totalImagesEl) {
        totalImagesEl.textContent = galleryItems.length;
    }

    /**
     * Update visible images counter
     */
    const updateVisibleCount = () => {
        const visibleCount = document.querySelectorAll('.gallery-item:not(.hidden)').length;
        if (visibleImagesEl) {
            visibleImagesEl.textContent = visibleCount;
        }
    };

    /**
     * Filter gallery items by category
     * @param {string} category - Category to filter by
     */
    const filterGallery = (category) => {
        galleryItems.forEach(item => {
            const itemCategory = item.getAttribute('data-category');
            
            if (category === 'all' || itemCategory === category) {
                // Show item with animation
                item.classList.remove('filtering-out', 'hidden');
                item.classList.add('filtering-in');
                
                setTimeout(() => {
                    item.classList.remove('filtering-in');
                }, 300);
            } else {
                // Hide item with animation
                item.classList.add('filtering-out');
                
                setTimeout(() => {
                    item.classList.remove('filtering-out');
                    item.classList.add('hidden');
                }, 300);
            }
        });

        // Update visible count after animation
        setTimeout(() => {
            updateVisibleCount();
        }, 350);
    };

    // Add click event to each filter button
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            const category = button.getAttribute('data-filter');

            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            // Filter gallery
            filterGallery(category);
        });
    });

    // Initialize with "all" selected
    updateVisibleCount();
};

// ===================================
// LOGO CAROUSEL AUTO-SCROLL
// ===================================

const initLogoCarousel = () => {
    const carouselTrack = document.querySelector('.logo-carousel__track');
    if (!carouselTrack) return;

    // Pause animation on hover is handled by CSS
    // This function can be extended for more complex carousel behavior
};

// ===================================
// LAZY LOADING IMAGES
// ===================================

const initLazyLoading = () => {
    const lazyImages = document.querySelectorAll('img[loading="lazy"]');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src || img.src;
                    img.classList.add('loaded');
                    imageObserver.unobserve(img);
                }
            });
        });

        lazyImages.forEach(img => imageObserver.observe(img));
    }
};

// ===================================
// HANDLE HASH LINKS ON PAGE LOAD
// ===================================

const handleHashLinks = () => {
    if (window.location.hash) {
        setTimeout(() => {
            const targetElement = document.querySelector(window.location.hash);
            if (targetElement) {
                smoothScrollTo(targetElement);
            }
        }, 100);
    }
};

// ===================================
// PERFORMANCE OPTIMIZATION
// ===================================

/**
 * Defer loading of non-critical resources
 */
const deferNonCriticalResources = () => {
    // Example: Defer loading of social media widgets
    // This can be expanded based on specific needs
};

// ===================================
// ANALYTICS & TRACKING (Optional)
// ===================================

const initAnalytics = () => {
    // Track outbound links
    document.querySelectorAll('a[href^="http"]').forEach(link => {
        if (!link.href.includes(window.location.hostname)) {
            link.addEventListener('click', () => {
                console.log('Outbound link clicked:', link.href);
                // Add your analytics tracking code here
            });
        }
    });

    // Track form submissions
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', () => {
            console.log('Form submitted:', form.id || 'unnamed form');
            // Add your analytics tracking code here
        });
    });
};

// ===================================
// ERROR HANDLING
// ===================================

/**
 * Global error handler
 */
window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    // Add error reporting service here if needed
});

/**
 * Handle unhandled promise rejections
 */
window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    // Add error reporting service here if needed
});

// ===================================
// INITIALIZATION
// ===================================

/**
 * Initialize all features when DOM is ready
 */
const init = () => {
    console.log('Initializing Nemafukani Livestock Website...');

    // Core functionality
    initMobileNav();
    initStickyHeader();
    initScrollToTop();
    initSmoothScroll();
    initScrollAnimations();
    
    // Page-specific functionality
    initFAQAccordion();
    initFAQSearch();
    initFAQCategoryFilter();
    initContactForm();
    initLightbox();
    initGalleryFilters();
    initLogoCarousel();
    initLazyLoading();
    
    // Additional features
    handleHashLinks();
    deferNonCriticalResources();
    initAnalytics();

    console.log('Nemafukani Livestock Website initialized successfully!');
};

// ===================================
// DOM READY
// ===================================

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

// ===================================
// WINDOW LOAD EVENT
// ===================================

window.addEventListener('load', () => {
    // Remove any loading overlays if present
    const loadingOverlay = document.querySelector('.loading-overlay');
    if (loadingOverlay) {
        loadingOverlay.style.opacity = '0';
        setTimeout(() => {
            loadingOverlay.remove();
        }, 300);
    }
});

// ===================================
// EXPORT FOR TESTING (Optional)
// ===================================

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        debounce,
        isInViewport,
        smoothScrollTo,
        initMobileNav,
        initContactForm,
        // ... other functions
    };
}